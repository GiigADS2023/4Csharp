﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _4Csharp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            /*4- Criar um vetor de cinco posições, solicitar  cinco números e ao fim, 
             * imprimir o valor apresentado na posição três.*/

            //Array para armazenar os 5 valores
            int[] numeros = new int[5];

            //Solicita 5 números
            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Digite o " + (i+1) + "º número:");
                numeros[i] = int.Parse(Console.ReadLine());
            }

            //Mostrar na tela o número que está na terceira posição
            Console.WriteLine("O valor na posição três é: " + numeros[2]);
            Console.ReadLine();
        }
    }
}
